#!/bin/bash
#                                                                    2020-02-10
#  prova ssh a scheda remota
#
ServiceName="script-server"
Home=$home
WorkDir="${Home}dockrepo/sysdata/${ServiceName}/scripts"
#
echo
echo
echo "---------------------------------------------------------"
echo "collegamento alla raspi"
echo
ssh pi@192.168.1.43
ls -la
echo "raspberry exit ..."
exit
echo
echo "Done."
