PARAM_TYPE_SERVER_FILE = 'server_file'
PARAM_TYPE_MULTISELECT = 'multiselect'
FILE_TYPE_FILE = 'file'
FILE_TYPE_DIR = 'dir'
