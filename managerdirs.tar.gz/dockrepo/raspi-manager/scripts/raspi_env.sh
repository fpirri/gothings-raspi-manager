#!/bin/bash
#                                                                    2021-11-10
#  Display script environment
#
ls -la
source scripts/include/RaspiNames.sh
#
echo
echo "WorkDir: ${WorkDir}"
echo "ScriptDir: ${ScriptDir}"
echo "IncludeDir: ${IncludeDir}"
echo "UploadsDir: ${UploadsDir}"
echo
echo "---------------------------------------------------------"
echo "Environment on this server"
echo
echo "User:  $(whoami)"
echo "Dir:   $(pwd)"
echo
echo "nodename $(uname -n)"
echo "kernel-name $(uname -s)"
echo "kernel-release $(uname -r)"
echo "kernel-version $(uname -v)"
echo "machine $(uname -m)"
echo "operating-system $(uname -o)"
echo "processor $(uname -p)"
echo "hardware-platform $(uname -i)"
echo
echo "Network:"
ip a
echo
echo "Done."
